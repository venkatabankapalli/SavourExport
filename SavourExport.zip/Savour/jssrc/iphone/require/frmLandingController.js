define({
    "navigateToHomeScreen": function() {
        var homeScreenNaivigation = new kony.mvc.Navigation("frmHome");
        homeScreenNaivigation.navigate();
    },
    "AS_Button_feb241d4c1ec4a92ac5db0f3fea9aa6a": function AS_Button_feb241d4c1ec4a92ac5db0f3fea9aa6a(eventobject) {
        var self = this;
        this.navigateToHomeScreen();
    }
})