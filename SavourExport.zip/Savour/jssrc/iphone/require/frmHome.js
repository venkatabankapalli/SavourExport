define("frmHome", function() {
    return function(controller) {
        function addWidgetsfrmHome() {
            this.setDefaultUnit(kony.flex.DP);
            var header = new com.vb.header({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "header",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "skin": "sknFlex1"
            }, {}, {});
            var imgSavour = new kony.ui.Image2({
                "height": "147dp",
                "id": "imgSavour",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "hotel.png",
                "top": "225dp",
                "width": "133dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDescription = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblDescription",
                "isVisible": true,
                "skin": "sknLbl1",
                "text": "Select range and shake your phone to find restaurants in that range",
                "top": "375dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblSelectRange = new kony.ui.Label({
                "id": "lblSelectRange",
                "isVisible": true,
                "left": "8dp",
                "skin": "sknLbl2",
                "text": "Selected Range: 0 miles",
                "top": "440dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var sliderRange = new kony.ui.Slider({
                "centerX": "50%",
                "focusThumbImage": "sliderthumb2.png",
                "height": "45dp",
                "id": "sliderRange",
                "isVisible": true,
                "left": "23dp",
                "leftSkin": "slSliderLeftBlue",
                "max": 100,
                "min": 0,
                "onSelection": controller.AS_Slider_b59a2bcda803460aa942e137ac5526a9,
                "onSlide": controller.AS_Slider_c06dfe04ca744c40a4883e6245ed175e,
                "rightSkin": "slSliderRightBlue",
                "selectedValue": 40,
                "step": 1,
                "thumbImage": "sliderthumb3.png",
                "top": "481dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {
                "thumbTintColor": "ffffff00"
            });
            var footer = new com.vb.footer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "footer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "skin": "sknFlex1"
            }, {}, {});
            this.add(header, imgSavour, lblDescription, lblSelectRange, sliderRange, footer);
        };
        return [{
            "addWidgets": addWidgetsfrmHome,
            "enabledForIdleTimeout": false,
            "id": "frmHome",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrm1"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "slTitleBar"
        }]
    }
});