define("frmHotelList", function() {
    return function(controller) {
        function addWidgetsfrmHotelList() {
            this.setDefaultUnit(kony.flex.DP);
            var header = new com.vb.header({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "header",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "skin": "sknFlex1"
            }, {}, {});
            var segHotelList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblHotelAddress": "Plot No. 2, Survey No. 64, Hitec City, Madhapur, Hyderabad, Telangana 500081",
                    "lblHotelName": "Lemon Tree Premium",
                    "lblRating": "Rating: 4.3"
                }, {
                    "lblHotelAddress": "Plot No. 2, Survey No. 64, Hitec City, Madhapur, Hyderabad, Telangana 500081",
                    "lblHotelName": "Lemon Tree Premium",
                    "lblRating": "Rating: 4.3"
                }, {
                    "lblHotelAddress": "Plot No. 2, Survey No. 64, Hitec City, Madhapur, Hyderabad, Telangana 500081",
                    "lblHotelName": "Lemon Tree Premium",
                    "lblRating": "Rating: 4.3"
                }],
                "groupCells": false,
                "height": "85%",
                "id": "segHotelList",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_d2381d1c734740d3b9fef4d66dc2fd89,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flexTplSegRow",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "50dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flexTplSegRow": "flexTplSegRow",
                    "lblHotelAddress": "lblHotelAddress",
                    "lblHotelName": "lblHotelName",
                    "lblRating": "lblRating"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "bounces": true,
                "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
                "enableDictionary": false,
                "indicator": constants.SEGUI_NONE,
                "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
                "showProgressIndicator": true
            });
            var footer = new com.vb.footer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "footer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "skin": "sknFlex1"
            }, {}, {});
            this.add(header, segHotelList, footer);
        };
        return [{
            "addWidgets": addWidgetsfrmHotelList,
            "enabledForIdleTimeout": false,
            "id": "frmHotelList",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrm1"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "slTitleBar"
        }]
    }
});