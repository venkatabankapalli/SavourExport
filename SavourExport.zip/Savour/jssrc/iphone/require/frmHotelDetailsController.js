define({
    "onNavigate": function(context) {
        this.view.header.imgBack.setVisibility(true);
        if (null !== context) {
            this.view.lblHotelName.text = context.name;
            this.view.lblHotelAddress.text = context.vicinity;
            this.view.lblRating.text = context.rating;
            this.view.mapHotels.locationData = [{
                "showcallout": true,
                "lat": context.lat,
                "lon": context.lon,
                "image": "pin.png",
                "name": context.name,
                "desc": context.vicinity
            }];
        }
    }
})