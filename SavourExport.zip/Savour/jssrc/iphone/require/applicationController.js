define({
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("com.vb.footer", "footer", "footerController");
        kony.application.registerMaster({
            "namespace": "com.vb",
            "classname": "footer",
            "name": "com.vb.footer"
        });
        kony.mvc.registry.add("com.vb.header", "header", "headerController");
        kony.application.registerMaster({
            "namespace": "com.vb",
            "classname": "header",
            "name": "com.vb.header"
        });
        kony.mvc.registry.add("flexTplSegRow", "flexTplSegRow", "flexTplSegRowController");
        kony.mvc.registry.add("frmHome", "frmHome", "frmHomeController");
        kony.mvc.registry.add("frmHotelDetails", "frmHotelDetails", "frmHotelDetailsController");
        kony.mvc.registry.add("frmHotelList", "frmHotelList", "frmHotelListController");
        kony.mvc.registry.add("frmLanding", "frmLanding", "frmLandingController");
        kony.application.setCheckBoxSelectionImageAlignment(constants.CHECKBOX_SELECTION_IMAGE_ALIGNMENT_RIGHT);
        kony.application.setDefaultTextboxPadding(false);
        kony.application.setRespectImageSizeForImageWidgetAlignment(true);
        setAppBehaviors();
        if (typeof startBackgroundWorker != "undefined") {
            startBackgroundWorker();
        }
    },
    postAppInitCallBack: function() {},
    appmenuseq: function() {
        new kony.mvc.Navigation("frmLanding").navigate();
    }
});