//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "Savour",
    appName: "Savour",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.10.27.74",
    serverPort: "80",
    secureServerPort: "443",
    isDebug: true,
    middlewareContext: "Savour",
    isturlbase: "http://kony145.local:8080/services",
    isMFApp: true,
    appKey: "707e4ede8fdecaf7be4ce8de1c06709e",
    appSecret: "e36c443c86b121a74ad4f70d7f18683d",
    serviceUrl: "http://kony145.local:8080/authService/100000002/appconfig",
    svcDoc: {
        "appId": "b04da164-b497-4994-a279-822fbbc7c20c",
        "baseId": "41771fc9-dee1-4417-9bf5-53a446985ed3",
        "name": "KonyGooglePlaces",
        "selflink": "http://kony145.local:8080/authService/100000002/appconfig",
        "integsvc": {
            "GooglePlaces": "http://kony145.local:8080/services/GooglePlaces",
            "GooglePlacesComposite": "http://kony145.local:8080/services/GooglePlacesComposite"
        },
        "reportingsvc": {
            "custom": "http://kony145.local:8080/services/CMS",
            "session": "http://kony145.local:8080/services/IST"
        },
        "services_meta": {
            "GooglePlaces": {
                "version": "1.0",
                "url": "http://kony145.local:8080/services/GooglePlaces",
                "type": "integsvc"
            },
            "GooglePlacesComposite": {
                "version": "1.0",
                "url": "http://kony145.local:8080/services/GooglePlacesComposite",
                "type": "integsvc"
            }
        }
    },
    svcDocRefresh: false,
    svcDocRefreshTimeSecs: -1,
    eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"],
    url: "http://kony145.local:8080/admin/Savour/MWServlet",
    secureurl: "http://kony145.local:8080/admin/Savour/MWServlet"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    kony.application.setCheckBoxSelectionImageAlignment(constants.CHECKBOX_SELECTION_IMAGE_ALIGNMENT_RIGHT);
    kony.application.setDefaultTextboxPadding(false);
    kony.application.setRespectImageSizeForImageWidgetAlignment(true);
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        isMVC: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 7300
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    applicationController = require("applicationController");
    callAppMenu();
    kony.application.setApplicationInitializationEvents({
        init: applicationController.appInit,
        showstartupform: function() {
            var startForm = new kony.mvc.Navigation("frmLanding");
            startForm.navigate();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "eventTypes": appConfig.eventTypes,
        "serviceUrl": appConfig.serviceUrl
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();
// If you wish to debug Application Initialization events, now is the time to
// place breakpoints.
debugger;