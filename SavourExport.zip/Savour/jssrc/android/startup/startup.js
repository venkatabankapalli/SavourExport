//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "Savour",
    appName: "Savour",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.10.27.74",
    serverPort: "80",
    secureServerPort: "443",
    isDebug: true,
    middlewareContext: "Savour",
    isturlbase: "https://training.konycloud.com/services",
    isMFApp: true,
    appKey: "f1c3424043477b3b27d5e996aa2d5acd",
    appSecret: "df43c93ab84210b2c6f39def6d5870a7",
    serviceUrl: "https://100000507.auth.konycloud.com/appconfig",
    svcDoc: {
        "appId": "27313397-2f82-4318-b508-70ed9043f8d0",
        "baseId": "ace34626-ac27-40c9-8572-c59bdfc36eab",
        "name": "KonyGooglePlaces",
        "selflink": "https://100000507.auth.konycloud.com/appconfig",
        "integsvc": {
            "GooglePlaces": "https://training.konycloud.com/services/GooglePlaces",
            "GooglePlacesComposite": "https://training.konycloud.com/services/GooglePlacesComposite"
        },
        "reportingsvc": {
            "custom": "https://training.konycloud.com/services/CMS",
            "session": "https://training.konycloud.com/services/IST"
        },
        "services_meta": {
            "GooglePlaces": {
                "version": "1.0",
                "url": "https://training.konycloud.com/services/GooglePlaces",
                "type": "integsvc"
            },
            "GooglePlacesComposite": {
                "version": "1.0",
                "url": "https://training.konycloud.com/services/GooglePlacesComposite",
                "type": "integsvc"
            }
        }
    },
    svcDocRefresh: false,
    svcDocRefreshTimeSecs: -1,
    eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"],
    url: "https://training.konycloud.com/Savour/MWServlet",
    secureurl: "https://training.konycloud.com/Savour/MWServlet"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        isMVC: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 7300
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    applicationController = require("applicationController");
    callAppMenu();
    kony.application.setApplicationInitializationEvents({
        init: applicationController.appInit,
        showstartupform: function() {
            var startForm = new kony.mvc.Navigation("frmHome");
            startForm.navigate();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "eventTypes": appConfig.eventTypes,
        "serviceUrl": appConfig.serviceUrl
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();
// If you wish to debug Application Initialization events, now is the time to
// place breakpoints.
debugger;