define("frmHotelDetails", function() {
    return function(controller) {
        function addWidgetsfrmHotelDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var header = new com.vb.header({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "header",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "skin": "sknFlex1"
            }, {}, {});
            var footer = new com.vb.footer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "footer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "skin": "sknFlex1"
            }, {}, {});
            var mapHotels = new kony.ui.Map({
                "calloutWidth": 80,
                "defaultPinImage": "pinb.png",
                "height": "50%",
                "id": "mapHotels",
                "isVisible": true,
                "left": "0dp",
                "provider": constants.MAP_PROVIDER_GOOGLE,
                "top": "50dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {
                "mode": constants.MAP_VIEW_MODE_NORMAL,
                "showZoomControl": true,
                "zoomLevel": 15
            });
            var flexTplSegRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flexTplSegRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "skin": "sknFlex2",
                "top": "60%",
                "width": "100%"
            }, {}, {});
            flexTplSegRow.setDefaultUnit(kony.flex.DP);
            var lblHotelName = new kony.ui.Label({
                "id": "lblHotelName",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLbl3",
                "text": "Lemon Tree Premium",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "5dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var lblHotelAddress = new kony.ui.Label({
                "id": "lblHotelAddress",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLbl1",
                "text": "Plot No. 2, Survey No. 64, Hitec City, Madhapur, Hyderabad, Telangana 500081",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var lblRating = new kony.ui.Label({
                "id": "lblRating",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLbl4",
                "text": "Rating: 4.3",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flexTplSegRow.add(lblHotelName, lblHotelAddress, lblRating);
            this.add(header, footer, mapHotels, flexTplSegRow);
        };
        return [{
            "addWidgets": addWidgetsfrmHotelDetails,
            "enabledForIdleTimeout": false,
            "id": "frmHotelDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrm1"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "footerOverlap": false,
            "headerOverlap": false,
            "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
            "retainScrollPosition": false,
            "titleBar": true,
            "titleBarSkin": "slTitleBar",
            "windowSoftInputMode": constants.FORM_ADJUST_PAN
        }]
    }
});