define({
    "onNavigate": function() {
        kony.print("*** Entering into frmHomeController - onNavigate ***");
        this.view.header.imgBack.setVisibility(false);
        kony.print("*** Exiting out of frmHomeController - onNavigate ***");
    },
    "setSelectedRangeValue": function() {
        kony.print("*** Entering into frmHomeController - setSelectedRangeValue ***");
        this.view.lblSelectRange.text = "Selected Range: " + this.view.sliderRange.selectedValue + " miles";
        kony.print("*** Exiting out of frmHomeController - setSelectedRangeValue ***");
    },
    "getCurrentPosition": function() {
        kony.print("*** Entering into frmHomeController - getCurrentPosition ***");
        var positionoptions = {
            enableHighAccuracy: false,
            timeout: 60000,
            maximumAge: 120000
        };
        showProgressIndicator("Retrieving current location");
        kony.location.getCurrentPosition(this.getCurrentPositionSuccessCallback, this.getCurrentPositionErrorCallback, positionoptions);
        kony.print("*** Exiting out of frmHomeController - getCurrentPosition ***");
    },
    "getCurrentPositionSuccessCallback": function(position) {
        kony.print("*** Entering into frmHomeController - getCurrentPositionSuccessCallback ***" + JSON.stringify(position));
        dismissLoadingIndicator();
        //alert ("getCurrentPositionSuccessCallback: "+JSON.stringify(position));
        this.fetchNearByRestaurants(position);
        kony.print("*** Exiting out of frmHomeController - getCurrentPositionSuccessCallback ***");
    },
    "getCurrentPositionErrorCallback": function(error) {
        kony.print("Entering into Controller for frmHome - getCurrentPositionErrorCallback: " + JSON.stringify(error));
        dismissLoadingIndicator();
        alert("Unable to retrieve current location. Please turn on locations service (GPS)");
        kony.print("Exiting out of getCurrentPositionErrorCallback in Controller for frmHome");
    },
    "onShakeGesture": function() {
        kony.print("*** Entering into frmHomeController - onShakeGesture ***");
        kony.accelerometer.unregisterAccelerationEvents(["shake"]);
        this.getCurrentPosition();
        kony.print("*** Exiting out of frmHomeController - onShakeGesture ***");
    },
    "setShakeGesture": function() {
        kony.print("*** Entering into frmHomeController - setShakeGesture ***");
        kony.accelerometer.registerAccelerationEvents({
            shake: this.onShakeGesture
        });
        kony.print("*** Exiting out of frmHomeController - setShakeGesture ***");
    },
    "searchForHotels": function() {
        kony.print("*** Entering into frmHomeController - searchForHotels ***");
        this.setShakeGesture();
        kony.print("*** Exiting out of frmHomeController - searchForHotels ***");
    },
    "fetchNearByRestaurants": function(position) {
        kony.print("*** Entering into frmHomeController - fetchNearByRestaurants ***");
        var selectedRange = this.view.sliderRange.selectedValue * 1000;
        //alert ("fetchNearByRestaurants: "+selectedRange+ "\nlatitude: "+position.coords.latitude+"\nlongitude: "+ position.coords.longitude);
        //var data = {"latitude": "17.4485314","longitude": "78.3700234","rankby": "prominence","type": "restaurant","radius": selectedRange+""};
        var googlePlaces = kony.sdk.getCurrentInstance().getIntegrationService("GooglePlaces");
        var data = {
            "latitude": position.coords.latitude,
            "longitude": position.coords.longitude,
            "rankby": "prominence",
            "type": "restaurant",
            "radius": selectedRange + ""
        };
        var headers = {};
        //dismissLoadingIndicator ();
        showProgressIndicator("Retrieving nearby restaurants");
        googlePlaces.invokeOperation("placeSearch", headers, data, this.fetchNearByRestaurantsSuccessCallback, this.fetchNearByRestaurantsFailureCallback);
        kony.print("*** Exiting out of frmHomeController - fetchNearByRestaurants ***");
    },
    "fetchNearByRestaurantsSuccessCallback": function(response) {
        kony.print("*** Entering into frmHomeController - fetchNearByRestaurantsSuccessCallback ***");
        dismissLoadingIndicator();
        //alert (JSON.stringify(response));
        var navigateToHotelList = new kony.mvc.Navigation("frmHotelList");
        navigateToHotelList.navigate(response);
        kony.print("*** Exiting out of frmHomeController - fetchNearByRestaurantsSuccessCallback ***");
    },
    "fetchNearByRestaurantsFailureCallback": function(error) {
        kony.print("*** Entering into frmHomeController - fetchNearByRestaurantsFailureCallback ***");
        dismissLoadingIndicator();
        alert("Unable to find nearby restaurants at this moment. Please try again later");
        kony.print("*** Exiting out of frmHomeController - fetchNearByRestaurantsFailureCallback ***");
    },
    "AS_Slider_c06dfe04ca744c40a4883e6245ed175e": function AS_Slider_c06dfe04ca744c40a4883e6245ed175e(eventobject, selectedvalue) {
        var self = this;
        this.setSelectedRangeValue();
    },
    "AS_Slider_b59a2bcda803460aa942e137ac5526a9": function AS_Slider_b59a2bcda803460aa942e137ac5526a9(eventobject, selectedvalue) {
        var self = this;
        this.searchForHotels();
    }
})