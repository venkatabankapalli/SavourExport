define({
    "onNavigate": function(context) {
        kony.print("*** Entering into frmHotelListController - onNavigate ***");
        if (null !== context) {
            kony.print("context: " + JSON.stringify(context));
            var hotelsList = context.placeSearchResults;
            this.view.segHotelList.widgetDataMap = {
                "lblHotelName": "name",
                "lblHotelAddress": "vicinity",
                "lblRating": "rating"
            };
            for (var i = 0; i < hotelsList.length; i++) hotelsList[i].rating = "Rating: " + hotelsList[i].rating;
            this.view.segHotelList.setData(hotelsList);
        }
        kony.print("*** Exiting out of frmHotelListController - onNavigate ***");
    },
    "showHotelDetails": function() {
        kony.print("*** Entering into frmHotelListController - showHotelDetails ***");
        var selectedHotel = this.view.segHotelList.selectedRowItems[0];
        //alert(JSON.stringify(selectedHotel));
        var navigateToHotelDetails = new kony.mvc.Navigation("frmHotelDetails");
        navigateToHotelDetails.navigate(selectedHotel);
        kony.print("*** Exiting out of frmHotelListController - showHotelDetails ***");
    },
    "AS_Segment_d2381d1c734740d3b9fef4d66dc2fd89": function AS_Segment_d2381d1c734740d3b9fef4d66dc2fd89(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.showHotelDetails();
    }
})