define(function() {
    return function(controller) {
        var footer = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "1dp",
            "clipBounds": true,
            "isMaster": true,
            "height": "50dp",
            "id": "footer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "skin": "sknFlex1",
            "width": "100%"
        }, {}, {});
        footer.setDefaultUnit(kony.flex.DP);
        var imgPoweredBy = new kony.ui.Image2({
            "centerY": "50.00%",
            "height": "225dp",
            "id": "imgPoweredBy",
            "isVisible": true,
            "left": "40dp",
            "skin": "slImage",
            "src": "powredby.png",
            "width": "230dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var imgKonyLogo = new kony.ui.Image2({
            "centerY": "50%",
            "height": "45dp",
            "id": "imgKonyLogo",
            "isVisible": true,
            "left": "211dp",
            "skin": "slImage",
            "src": "konyicon.png",
            "width": "59dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        footer.add(imgPoweredBy, imgKonyLogo);
        return footer;
    }
})