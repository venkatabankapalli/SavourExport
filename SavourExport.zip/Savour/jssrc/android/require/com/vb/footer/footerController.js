define(function() {
    var controller = require("com/vb/footer/userfooterController");
    var actions = require("com/vb/footer/footerControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});