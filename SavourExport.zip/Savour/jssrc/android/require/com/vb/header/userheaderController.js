define(function() {
    return {
        /**
         * @function navigateToPreviousForm
         * The function will be assigned to the onClick event of the imgBack.
         * This function will be called when the back button is clicked to navigate back to the previous form.
         */
        navigateToPreviousForm: function() {
            kony.print("*** Entering into navigateToPreviousForm ***");
            var currentFormID = kony.application.getCurrentForm().id;
            if ("frmHotelDetails" === currentFormID) {
                var navigateToFrmHotelList = new kony.mvc.Navigation("frmHotelList");
                navigateToFrmHotelList.navigate(null);
            } else if ("frmHotelList" === currentFormID) {
                var navigateToFrmHome = new kony.mvc.Navigation("frmHome");
                navigateToFrmHome.navigate();
            }
            kony.print("*** Exiting out of navigateToPreviousForm ***");
        }
    };
});