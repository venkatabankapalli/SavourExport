define(function() {
    return function(controller) {
        var header = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "50dp",
            "id": "header",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "skin": "sknFlex1",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        header.setDefaultUnit(kony.flex.DP);
        var imgKonyLogo = new kony.ui.Image2({
            "centerX": "50%",
            "centerY": "50%",
            "height": "45dp",
            "id": "imgKonyLogo",
            "isVisible": true,
            "skin": "slImage",
            "src": "konylogo.png",
            "width": "140dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var imgBack = new kony.ui.Image2({
            "centerY": "50%",
            "height": "45dp",
            "id": "imgBack",
            "isVisible": true,
            "left": "5dp",
            "onTouchEnd": controller.AS_Image_a990b4153f0a4c2aa9c9e9354b7bb3a9,
            "skin": "slImage",
            "src": "back.png",
            "top": "12dp",
            "width": "55dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        header.add(imgKonyLogo, imgBack);
        return header;
    }
})