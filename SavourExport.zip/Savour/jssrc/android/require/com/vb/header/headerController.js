define(function() {
    var controller = require("com/vb/header/userheaderController");
    var actions = require("com/vb/header/headerControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});