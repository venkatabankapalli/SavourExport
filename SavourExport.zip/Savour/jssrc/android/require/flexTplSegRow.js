define("flexTplSegRow", function() {
    return function(controller) {
        var flexTplSegRow = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flexTplSegRow",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "skin": "sknFlex2"
        }, {}, {});
        flexTplSegRow.setDefaultUnit(kony.flex.DP);
        var lblHotelName = new kony.ui.Label({
            "id": "lblHotelName",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLbl3",
            "text": "Lemon Tree Premium",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "5dp",
            "width": "95%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        var lblHotelAddress = new kony.ui.Label({
            "id": "lblHotelAddress",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLbl1",
            "text": "Plot No. 2, Survey No. 64, Hitec City, Madhapur, Hyderabad, Telangana 500081",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "10dp",
            "width": "95%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        var lblRating = new kony.ui.Label({
            "id": "lblRating",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLbl4",
            "text": "Rating: 4.3",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "10dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        flexTplSegRow.add(lblHotelName, lblHotelAddress, lblRating);
        return flexTplSegRow;
    }
})