//actions.js file 
function AS_Image_a990b4153f0a4c2aa9c9e9354b7bb3a9(eventobject, x, y) {
    var self = this;
    this.navigateToPreviousForm();
}