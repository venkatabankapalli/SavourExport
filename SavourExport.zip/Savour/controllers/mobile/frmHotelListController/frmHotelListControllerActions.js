define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Segment_d2381d1c734740d3b9fef4d66dc2fd89: function AS_Segment_d2381d1c734740d3b9fef4d66dc2fd89(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.showHotelDetails();
    }
});