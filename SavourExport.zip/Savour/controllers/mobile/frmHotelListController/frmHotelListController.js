define({ 

  //Type your controller code here 
  /**
   * @function
   * This function is a lifecycle function, it will called each time while navigating to frmHotelList
   * In this function we will set the hotel list to the segment widget on the screen
   */
  onNavigate: function (context) {
    kony.print ("*** Entering into frmHotelListController - onNavigate ***");
    this.view.header.imgBack.setVisibility(true);
    if (null !== context) {
      kony.print ("context: "+JSON.stringify(context));
      var hotelsList = context.placeSearchResults;
      this.view.segHotelList.widgetDataMap = {"lblHotelName":"name","lblHotelAddress":"vicinity","lblRating":"rating"};
      for (var i = 0; i<hotelsList.length; i++)
        hotelsList[i].rating = "Rating: "+hotelsList[i].rating;
      this.view.segHotelList.setData (hotelsList);
    }
    kony.print ("*** Exiting out of frmHotelListController - onNavigate ***");
  },
  
  /**
   * @function showHotelDetails
   * This function is called when user selectes one of the hotels listed in the frmHotelList screen
   * This function will navigate the user to the frmHotelDetails screen
   */
  showHotelDetails: function (){
    kony.print ("*** Entering into frmHotelListController - showHotelDetails ***");
    var selectedHotel = this.view.segHotelList.selectedRowItems[0];
    //alert(JSON.stringify(selectedHotel));
    var navigateToHotelDetails = new kony.mvc.Navigation("frmHotelDetails");
    navigateToHotelDetails.navigate(selectedHotel);
    kony.print ("*** Exiting out of frmHotelListController - showHotelDetails ***");    
  }
  
});