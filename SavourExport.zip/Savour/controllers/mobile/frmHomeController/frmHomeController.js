define({ 

  //Type your controller code here 
  /**
   * @function onNavigate
   * This function is a lifecycle function, it will called each time while navigating to frmHome
   * In this function we will make the back button which is present as part of component as invisible
   */
  onNavigate: function () {
	kony.print ("*** Entering into frmHomeController - onNavigate ***");
    this.view.header.imgBack.setVisibility(false);
	kony.print ("*** Exiting out of frmHomeController - onNavigate ***");
  },
  
  /**
   * @function setSelectedRangeValue
   * This function is to updated the selected range on to the screen
   * This function will be invoked while the user is sliding on the range slider widget
   */
  setSelectedRangeValue : function () {
	kony.print ("*** Entering into frmHomeController - setSelectedRangeValue ***");
    this.view.lblSelectRange.text = "Selected Range: " + this.view.sliderRange.selectedValue + " miles";
	kony.print ("*** Exiting out of frmHomeController - setSelectedRangeValue ***");
  },
  
  /**
   * @function getCurrentPosition
   * This function is used to get the current position of the device
   * This function will be called in the shake gesture handler 
   */
  getCurrentPosition: function () {
	kony.print ("*** Entering into frmHomeController - getCurrentPosition ***");
    var positionoptions = {enableHighAccuracy: false, timeout: 60000, maximumAge: 120000};
    showProgressIndicator ("Retrieving current location");
    kony.location.getCurrentPosition(this.getCurrentPositionSuccessCallback, 
                                     this.getCurrentPositionErrorCallback, 
                                     positionoptions);
	kony.print ("*** Exiting out of frmHomeController - getCurrentPosition ***");
  },
  
  /**
   * @function getCurrentPositionSuccessCallback
   * This function is called when the app is able to successfully retrieve the current position of the device
   * @param position 
   */
  getCurrentPositionSuccessCallback: function (position) {
	kony.print ("*** Entering into frmHomeController - getCurrentPositionSuccessCallback ***"+JSON.stringify(position));
    dismissLoadingIndicator ();
    //alert ("getCurrentPositionSuccessCallback: "+JSON.stringify(position));
    this.fetchNearByRestaurants (position);
	kony.print ("*** Exiting out of frmHomeController - getCurrentPositionSuccessCallback ***");
  },
  
  /**
   * @function getCurrentPositionErrorCallback
   * This function is called when the app is unable to retrieve the current position of the device
   * @param error 
   */
  getCurrentPositionErrorCallback: function (error) {
	kony.print ("Entering into Controller for frmHome - getCurrentPositionErrorCallback: "+JSON.stringify(error));
    dismissLoadingIndicator ();
    alert ("Unable to retrieve current location. Please turn on locations service (GPS)");
	kony.print ("Exiting out of getCurrentPositionErrorCallback in Controller for frmHome");
  },
  
  /**
   * @function onShakeGesture
   * This is the callback function which will get invoked when shake gesture is performed on frmHome
   */
  onShakeGesture: function () {
	kony.print ("*** Entering into frmHomeController - onShakeGesture ***");
    kony.accelerometer.unregisterAccelerationEvents(["shake"]);
    this.getCurrentPosition ();
	kony.print ("*** Exiting out of frmHomeController - onShakeGesture ***");
  },
  
  /**
   * @function setShakeGesture
   * This function is to set the shake gesture to frmHome
   * This function will be invokes in the init event of frmHome, to set the shake gesture to the frmHome
   *
   */
  setShakeGesture: function () {
	kony.print ("*** Entering into frmHomeController - setShakeGesture ***");
    kony.accelerometer.registerAccelerationEvents({shake:this.onShakeGesture});
	kony.print ("*** Exiting out of frmHomeController - setShakeGesture ***");
  },
  
  /**
   * @function searchForHotels
   * This function is used to search for hotels in the selected range
   * This function will be called in the onSelection event of the slider
   */
  searchForHotels: function () {
	kony.print ("*** Entering into frmHomeController - searchForHotels ***");  
	this.setShakeGesture();
    kony.print ("*** Exiting out of frmHomeController - searchForHotels ***");  
  },
  
  /**
   * @function fetchNearByRestaurants
   * This function will be called after app is able to successfully retrieve the current position of the device
   * This function will perform service call to MobileFabric to retrive the list of hotels in the current position of the device,
   * within the selected range
   * @param position 
   */
  fetchNearByRestaurants: function (position) {
    kony.print ("*** Entering into frmHomeController - fetchNearByRestaurants ***");
    var selectedRange = this.view.sliderRange.selectedValue*1000;
    //alert ("fetchNearByRestaurants: "+selectedRange+ "\nlatitude: "+position.coords.latitude+"\nlongitude: "+ position.coords.longitude);
    //var data = {"latitude": "17.4485314","longitude": "78.3700234","rankby": "prominence","type": "restaurant","radius": selectedRange+""};
    var googlePlaces = kony.sdk.getCurrentInstance().getIntegrationService  ("GooglePlaces");
	var data = {"latitude": position.coords.latitude,
                "longitude": position.coords.longitude,
                "rankby": "prominence","type": "restaurant","radius": selectedRange+""};
    var headers= {};
    //dismissLoadingIndicator ();
    showProgressIndicator ("Retrieving nearby restaurants");
    googlePlaces.invokeOperation("placeSearch", headers, data, 
                                 this.fetchNearByRestaurantsSuccessCallback, 
                                 this.fetchNearByRestaurantsFailureCallback);
    kony.print ("*** Exiting out of frmHomeController - fetchNearByRestaurants ***");
  },
  
  /**
   * @function fetchNearByRestaurantsSuccessCallback
   * This function is called after the list of hotels are successfully retrieved from the service call
   * This function will pass the list of hotels to the frmHotelList screen
   * @param response 
   */
  fetchNearByRestaurantsSuccessCallback: function (response) {
	kony.print ("*** Entering into frmHomeController - fetchNearByRestaurantsSuccessCallback ***");
    dismissLoadingIndicator ();
    //alert (JSON.stringify(response));
    var navigateToHotelList = new kony.mvc.Navigation("frmHotelList");
    navigateToHotelList.navigate(response);
	kony.print ("*** Exiting out of frmHomeController - fetchNearByRestaurantsSuccessCallback ***");
  },
  
  /**
   * @function fetchNearByRestaurantsFailureCallback
   * This function is called if the service call to fetch the list of hotels is failed
   * @param error 
   */
  fetchNearByRestaurantsFailureCallback: function (error) {
	kony.print ("*** Entering into frmHomeController - fetchNearByRestaurantsFailureCallback ***");
    dismissLoadingIndicator ();
    alert ("Unable to find nearby restaurants at this moment. Please try again later");
	kony.print ("*** Exiting out of frmHomeController - fetchNearByRestaurantsFailureCallback ***");
  }

});