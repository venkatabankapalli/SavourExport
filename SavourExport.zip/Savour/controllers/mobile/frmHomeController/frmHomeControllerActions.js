define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Slider_c06dfe04ca744c40a4883e6245ed175e: function AS_Slider_c06dfe04ca744c40a4883e6245ed175e(eventobject, selectedvalue) {
        var self = this;
        this.setSelectedRangeValue();
    },
    AS_Slider_b59a2bcda803460aa942e137ac5526a9: function AS_Slider_b59a2bcda803460aa942e137ac5526a9(eventobject, selectedvalue) {
        var self = this;
        this.searchForHotels();
    }
});