define({ 

  //Type your controller code here 
  /**
   * @function onNavigate
   * This function is a lifecycle function, it will called each time while navigating to frmHotelDetails
   * In this function we will set the details of the selected hotel onto the labels which we have on the screen
   */
  onNavigate: function (context) {
    this.view.header.imgBack.setVisibility(true);
    if (null !== context) {
      this.view.lblHotelName.text=context.name;
      this.view.lblHotelAddress.text=context.vicinity;
      this.view.lblRating.text=context.rating;
      this.view.mapHotels.locationData=[{"showcallout":true,"lat":context.lat,"lon":context.lon,"image":"pin.png","name":context.name,"desc":context.vicinity}];
    }
  }
});